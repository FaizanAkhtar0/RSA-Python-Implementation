from models.rsa import RSA

rsa = RSA()

public, private = rsa.generate_keys(13, 5)

message = "Hello"

print(f"Original Message: '{message}'")

print(f"Original Message Bytes: {rsa.convert_to_bytes(message)}")

encrypted_bytes = rsa.encrypt(public, message)

print(f"Encrypted Bytes: {encrypted_bytes}")

chiper = rsa.convert_to_text(encrypted_bytes)

print(f"Encrypted Representation: '{chiper}'")

print(f"Decryption: '{rsa.decrypt(private, chiper)}'")
