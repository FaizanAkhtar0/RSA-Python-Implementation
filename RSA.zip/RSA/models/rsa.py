import random


class RSA:

    def __gcd(self, a, b, presentation=False):
        if presentation:
            print("Showing How E was calculated where gcd == 1")
        while b != 0:
            if presentation:
                print(f"----------------------------------------------------------------")
                print(f"Performing (a, b = b, a % b)")
                print(f"{a}, {b} = {b}, {a % b}")
                a, b = b, a % b
                print(f"----------------------------------------------------------------")
            else:
                a, b = b, a % b
        return a

    def __multiplicative_inverse(self, e, phi):
        d = 0
        x1 = 0
        x2 = 1
        y1 = 1
        temp_phi = phi

        original_e = e
        moded_value = int(temp_phi / e)

        print(f"Euclid's Extended algorithm to find multiplicative inverse of two numbers for calculating (d)")
        print(f"----------------------------------------------------------------")
        while e > 0:
            temp1 = int(temp_phi / e)
            print(f"Maths: {temp_phi} / {e} = {temp1}")
            temp2 = temp_phi - temp1 * e
            print(f"Maths: {temp_phi} - {temp1} * {e} = {temp2}")
            temp_phi = e
            e = temp2

            x = x2 - temp1 * x1
            y = d - temp1 * y1

            x2 = x1
            x1 = x
            d = y1
            y1 = y

        print(f"----------------------------------------------------------------")
        if temp_phi == 1:
            print(f"----------------------------------------------------------------Final")
            print(f"d: {original_e}^(-1) mod {moded_value} = {d + phi}")
            print(f"----------------------------------------------------------------Final")
            return d + phi

    def is_prime(self, number):
        if number == 2:
            return True
        elif number < 2 or number % 2 == 0:
            return False
        for x in range(3, int(number**0.5)+2, 2):
            if number % x == 0:
                return False
        return True

    def generate_keys(self, p, q):
        if not (self.is_prime(p) and self.is_prime(q)):
            raise ValueError('Both p and q must be prime!')
        elif p == q:
            raise ValueError('Both can not be equal')

        n = p * q
        print(f"n: {p} * {q} = {n}")

        phi = (p - 1) * (q - 1)
        print(f"PHI: ({p} -1) ({q} - 1) = {phi}")

        # e = random.randrange(1, phi)
        # print(f"1st Random (e): {e}")

        e = 5
        print(f"1st Random (e): {e}")

        g = self.__gcd(e, phi)
        print(f"1st Random value (gcd): {g}")
        while g != 1:
            e = random.randrange(1, phi)
            print(f"While - Random (e): {e}")
            g = self.__gcd(e, phi)
            print(f"while - Random value (gcd): {g}")

        if g == 1:
            self.__gcd(e, phi, presentation=True)

        d = self.__multiplicative_inverse(e, phi)

        print(f"Keys(public, private): {((e, n), (d, n))}")
        print(f"----------------------------------------------------------------")
        return ((e, n), (d, n))

    def encrypt(self, pk, plaintext):
        # Unpack the key into it's components
        key, n = pk
        # Convert each letter in the plaintext to numbers based on the character using a^b mod m
        cipher = [(ord(char) ** key) % n for char in plaintext]
        # Return the array of bytes
        return cipher

    def decrypt(self, pk, ciphertext):
        # Unpack the key into its components
        key, n = pk
        # Generate the plaintext based on the ciphertext and key using a^b mod m
        plain = [chr((ord(char) ** key) % n) for char in ciphertext]
        # Return the array of bytes as a string
        return ''.join(plain)

    def convert_to_bytes(self, message):
        return [ord(char) for char in message]

    def convert_to_text(self, encrypted_bytes):
        value = []
        for item in encrypted_bytes:
            value.append(chr(item))
        return ''.join(value)

